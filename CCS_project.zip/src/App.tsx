import { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, CheckCircle } from 'lucide-react';

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-giga-dark text-giga-text">
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled ? 'bg-giga-dark/95 backdrop-blur border-b border-giga-border' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex items-center justify-between h-20">
            <div className="text-2xl font-bold text-giga-text">
              Cerrado
            </div>

            <div className="hidden md:flex items-center space-x-12">
              <button onClick={() => scrollToSection('products')} className="text-giga-text-secondary hover:text-giga-text transition-colors text-sm font-medium">
                Products
              </button>
              <button onClick={() => scrollToSection('services')} className="text-giga-text-secondary hover:text-giga-text transition-colors text-sm font-medium">
                Services
              </button>
              <button onClick={() => scrollToSection('managed-services')} className="text-giga-text-secondary hover:text-giga-text transition-colors text-sm font-medium">
                Managed Services
              </button>
              <button onClick={() => scrollToSection('why-us')} className="text-giga-text-secondary hover:text-giga-text transition-colors text-sm font-medium">
                Why Choose Us
              </button>
              <button
                onClick={() => scrollToSection('cta')}
                className="giga-button-primary"
              >
                Schedule
              </button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-giga-accent p-2"
            >
              {mobileMenuOpen ? <X size={32} /> : <Menu size={32} />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 top-20 bg-giga-card z-30 w-full h-screen border-t border-giga-border">
            <div className="px-6 py-12 space-y-8">
              <button
                onClick={() => scrollToSection('products')}
                className="block w-full text-left text-giga-text py-4 text-2xl font-medium border-b border-giga-border"
              >
                Products
              </button>
              <button
                onClick={() => scrollToSection('services')}
                className="block w-full text-left text-giga-text py-4 text-2xl font-medium border-b border-giga-border"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection('managed-services')}
                className="block w-full text-left text-giga-text py-4 text-2xl font-medium border-b border-giga-border"
              >
                Managed Services
              </button>
              <button
                onClick={() => scrollToSection('why-us')}
                className="block w-full text-left text-giga-text py-4 text-2xl font-medium border-b border-giga-border"
              >
                Why Choose Us
              </button>
              <button
                onClick={() => scrollToSection('cta')}
                className="giga-button-primary w-full mt-8"
              >
                Schedule Consultation
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-40 pb-48 px-6 lg:px-12 bg-giga-gradient-subtle">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-6xl lg:text-8xl font-bold text-giga-text mb-8 leading-tight">
            Cerrado Consulting Services
          </h1>
          <p className="text-2xl lg:text-3xl text-giga-accent font-semibold mb-8">
            Pioneering AI-First Enterprise Transformation
          </p>
          <p className="text-xl lg:text-2xl text-giga-text-secondary mb-16 leading-relaxed">
            Where Strategy Meets Innovation, Powered by AI
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <button
              onClick={() => scrollToSection('cta')}
              className="giga-button-primary flex items-center gap-2"
            >
              Schedule Consultation
              <ArrowRight size={20} />
            </button>
            <button
              onClick={() => scrollToSection('products')}
              className="giga-button-secondary flex items-center gap-2"
            >
              Explore Solutions
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-32 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-16 text-center">
            <div className="giga-card">
              <div className="text-5xl lg:text-6xl font-bold text-giga-accent mb-4">500+</div>
              <p className="text-giga-text-secondary text-lg leading-relaxed">Successful AI Implementations</p>
            </div>
            <div className="giga-card">
              <div className="text-5xl lg:text-6xl font-bold text-giga-accent mb-4">95%+</div>
              <p className="text-giga-text-secondary text-lg leading-relaxed">Client Satisfaction Rating</p>
            </div>
            <div className="giga-card">
              <div className="text-5xl lg:text-6xl font-bold text-giga-accent mb-4">$2B+</div>
              <p className="text-giga-text-secondary text-lg leading-relaxed">Documented Value Creation</p>
            </div>
            <div className="giga-card">
              <div className="text-5xl lg:text-6xl font-bold text-giga-accent mb-4">50+</div>
              <p className="text-giga-text-secondary text-lg leading-relaxed">Industry Awards</p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-32 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-32">
            <h2 className="giga-section-title">
              Our Products
            </h2>
            <p className="text-xl text-giga-text-secondary max-w-3xl mx-auto leading-relaxed">
              Cutting-edge AI solutions designed to transform your business operations.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            <div className="giga-card flex flex-col">
              <h3 className="text-2xl font-bold text-giga-text mb-3">
                Virinchi Analytics
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-8">
                Transform Data Chaos into Strategic Intelligence
              </p>
              <ul className="space-y-4 mb-12 flex-grow">
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>Unified data platform</span>
                </li>
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>AI-powered insights</span>
                </li>
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>Predictive analytics</span>
                </li>
              </ul>
              <div className="pt-8 border-t border-giga-border">
                <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">60-70%</span> reduction in data prep time</p>
              </div>
            </div>

            <div className="giga-card flex flex-col">
              <h3 className="text-2xl font-bold text-giga-text mb-3">
                Virinchi Customer Excellence
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-8">
                AI-Powered Customer Success Platform
              </p>
              <ul className="space-y-4 mb-12 flex-grow">
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>Omnichannel support (voice, email, chat)</span>
                </li>
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>Smart analytics</span>
                </li>
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>SLA monitoring</span>
                </li>
              </ul>
              <div className="pt-8 border-t border-giga-border">
                <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">50-70%</span> reduction in response times</p>
              </div>
            </div>

            <div className="giga-card flex flex-col">
              <h3 className="text-2xl font-bold text-giga-text mb-3">
                Virinchi Bolt AI
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-8">
                Democratize AI Development Across Your Enterprise
              </p>
              <ul className="space-y-4 mb-12 flex-grow">
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>No-code AI development</span>
                </li>
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>Rapid prototyping</span>
                </li>
                <li className="flex gap-3 text-giga-text-secondary leading-relaxed">
                  <CheckCircle size={20} className="text-giga-accent flex-shrink-0 mt-0.5" />
                  <span>Citizen data scientists</span>
                </li>
              </ul>
              <div className="pt-8 border-t border-giga-border">
                <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">70-80%</span> reduction in time to MVP</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-32 px-6 lg:px-12 bg-giga-gradient-subtle">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-32">
            <h2 className="giga-section-title">
              Our Services
            </h2>
            <p className="text-xl text-giga-text-secondary max-w-3xl mx-auto leading-relaxed">
              Comprehensive solutions to accelerate your AI transformation journey.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="giga-card">
              <h3 className="text-2xl font-bold text-giga-text mb-2">
                AI Adoption & Strategy
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-6">
                From Vision to Execution
              </p>
              <p className="text-giga-text-secondary text-lg leading-relaxed mb-6">
                Strategic guidance to integrate AI capabilities across your organization, ensuring alignment with business objectives and measurable outcomes.
              </p>
              <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">Key Focus:</span> Roadmaps, architecture, transformation plans</p>
            </div>

            <div className="giga-card">
              <h3 className="text-2xl font-bold text-giga-text mb-2">
                Integrated Innovation Cycle
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-6">
                End-to-End Partnership
              </p>
              <p className="text-giga-text-secondary text-lg leading-relaxed mb-6">
                End-to-end innovation framework that combines ideation, rapid prototyping, and scaled deployment to drive continuous improvement.
              </p>
              <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">Key Focus:</span> Advisory, building, integration, management</p>
            </div>

            <div className="giga-card">
              <h3 className="text-2xl font-bold text-giga-text mb-2">
                Risk Mitigation & GRC
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-6">
                AI-Powered Governance
              </p>
              <p className="text-giga-text-secondary text-lg leading-relaxed mb-6">
                Comprehensive governance, risk management, and compliance frameworks tailored for AI-driven enterprises.
              </p>
              <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">Key Focus:</span> Predictive analytics, compliance automation</p>
            </div>

            <div className="giga-card">
              <h3 className="text-2xl font-bold text-giga-text mb-2">
                M&A & Operational Strategy
              </h3>
              <p className="text-lg text-giga-accent font-semibold mb-6">
                Navigate Complexity
              </p>
              <p className="text-giga-text-secondary text-lg leading-relaxed mb-6">
                Strategic advisory for mergers, acquisitions, and operational transformation to maximize value and accelerate growth.
              </p>
              <p className="text-giga-text-secondary leading-relaxed"><span className="font-semibold text-giga-accent">Key Focus:</span> Integration, continuity, synergy capture</p>
            </div>
          </div>
        </div>
      </section>

      {/* Managed Services Section */}
      <section id="managed-services" className="py-32 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-32">
            <h2 className="giga-section-title">
              Managed Services
            </h2>
            <p className="text-xl text-giga-text-secondary max-w-3xl mx-auto leading-relaxed">
              Comprehensive support to keep your AI systems running at peak performance.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
            <div className="giga-card text-center">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Application, Data & AI
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">Modernization with Intelligence</p>
            </div>

            <div className="giga-card text-center">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Cloud Services
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">Hybrid & Multi-Cloud Excellence</p>
            </div>

            <div className="giga-card text-center">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Enterprise Applications
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">Mission-Critical Support</p>
            </div>

            <div className="giga-card text-center">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Network & Security
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">Zero-Trust Protection</p>
            </div>

            <div className="giga-card text-center">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Resiliency & Storage
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">Unbreakable Business Continuity</p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="why-us" className="py-32 px-6 lg:px-12 bg-giga-gradient-subtle">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-32">
            <h2 className="giga-section-title">
              Why Choose Us
            </h2>
            <p className="text-xl text-giga-text-secondary max-w-3xl mx-auto leading-relaxed">
              Partner with experts who understand both technology and business transformation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
            <div className="giga-card">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                AI-First Approach
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">
                Intelligence at the core of every solution
              </p>
            </div>

            <div className="giga-card">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Enterprise-Ready
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">
                Battle-tested, scalable solutions
              </p>
            </div>

            <div className="giga-card">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                End-to-End Support
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">
                From strategy to operations
              </p>
            </div>

            <div className="giga-card">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Proven Technology
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">
                Powered by Virinchi AI platform
              </p>
            </div>

            <div className="giga-card">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Risk-Aware
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">
                Proactive security and governance
              </p>
            </div>

            <div className="giga-card">
              <h3 className="text-xl font-bold text-giga-text mb-3">
                Accelerated Value
              </h3>
              <p className="text-giga-text-secondary leading-relaxed">
                40-60% faster implementation
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="cta" className="py-32 px-6 lg:px-12 bg-giga-gradient">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl lg:text-6xl font-bold text-giga-text mb-8">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl lg:text-2xl text-giga-text mb-12 leading-relaxed">
            Let's discuss how AI can drive your next phase of growth and create lasting competitive advantage.
          </p>
          <button className="px-10 py-4 bg-giga-text text-giga-dark rounded-lg hover:bg-opacity-90 transition-all duration-300 text-lg font-semibold hover:shadow-2xl">
            Schedule a Consultation
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 lg:px-12 bg-giga-darker border-t border-giga-border">
        <div className="max-w-7xl mx-auto text-center">
          <div className="text-2xl font-bold bg-giga-gradient bg-clip-text text-transparent mb-4">
            Cerrado
          </div>
          <p className="text-gray-300 mb-8">
            AI-First Enterprise Transformation
          </p>
          <p className="text-gray-500 text-sm">
            &copy; 2025 Cerrado Consulting Services. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
