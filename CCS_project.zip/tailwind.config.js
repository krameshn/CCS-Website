/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'giga-dark': '#0d0d0d',
        'giga-darker': '#000000',
        'giga-card': '#1a1a1a',
        'giga-border': '#333333',
        'giga-text': '#ffffff',
        'giga-text-secondary': '#a3a3a3',
        'giga-accent': '#00e5ff',
        'giga-accent-secondary': '#7c3aed',
      },
      backgroundImage: {
        'giga-gradient': 'linear-gradient(135deg, #00e5ff 0%, #7c3aed 100%)',
        'giga-gradient-subtle': 'linear-gradient(135deg, rgba(0, 229, 255, 0.05) 0%, rgba(124, 58, 237, 0.05) 100%)',
      },
      fontFamily: {
        'sora': ['Sora', 'sans-serif'],
        'manrope': ['Manrope', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
